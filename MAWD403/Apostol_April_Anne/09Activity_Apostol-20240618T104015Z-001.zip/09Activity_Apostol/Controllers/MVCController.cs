﻿using Microsoft.AspNetCore.Mvc;

namespace _09Activity_Apostol.Controllers
{
    public class MVCController : Controller
    {
        public IActionResult Welcome(string name, int numtimes = 1)
        {
            ViewBag.Message = "Hello " + name;
            ViewBag.NumTimes = numtimes;

            return View();
        }
    }
}
