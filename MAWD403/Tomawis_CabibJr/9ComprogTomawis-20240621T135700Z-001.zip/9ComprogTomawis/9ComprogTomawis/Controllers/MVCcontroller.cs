﻿using Microsoft.AspNetCore.Mvc;

namespace _9ComprogTomawis.Controllers
{
    public class MVCcontroller : Controller
    {
        public IActionResult Index(string name, int NumTimes = 1)
        {
            ViewBag.Message = "Hello " + name;

            ViewBag.NumTimes = NumTimes;
            

            return View();
        }
    }
}
