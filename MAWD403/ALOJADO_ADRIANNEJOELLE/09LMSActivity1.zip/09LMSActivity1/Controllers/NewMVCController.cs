﻿using Microsoft.AspNetCore.Mvc;

namespace _09LMSActivity1.Controllers
{
    public class NewMVCController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult Welcome(string name, int numTimes = 1)
        {
            ViewBag.Message = $"Hello there, {name}.";
            ViewBag.NumTimes = numTimes;

            return View();
        }
    }
}
