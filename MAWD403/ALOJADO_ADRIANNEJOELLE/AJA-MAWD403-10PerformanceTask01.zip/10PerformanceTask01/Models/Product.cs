﻿using System.ComponentModel.DataAnnotations;

namespace _10PerformanceTask01.Models
{
    public class Product

    {

        [Key]
        public int ProductID { get; set; }

        [Required]
        public required string ProductName { get; set; }

        public string? Brand { get; set; }

        [Required]
        public decimal Price { get; set; }

    }

    
}
