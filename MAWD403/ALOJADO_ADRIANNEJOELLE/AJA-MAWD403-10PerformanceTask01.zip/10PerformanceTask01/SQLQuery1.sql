create table tblProducts
(
	ProductID int NOT NULL,
	ProductName varchar(50) NOT NULL,
	Brand varchar(50),
	Price float NOT NULL,
);
insert into tblProducts
values (
	'11111', 'pencilpack', 'Monggol', '20.00'
)
insert into tblProducts
values(
	'11112', 'penpack', 'Panda', '25.00'
)
insert into tblProducts
values(
	'11113', 'paper', '', '38.00'
)
insert into tblProducts
values(
	'11114', 'glue', 'Elnmers', '25.00'
)
insert into tblProducts
values(
	'11115', 'Scissors', '', '38.00'
)
delete from tblProducts where ProductID = 11113
update tblProducts set Price = 35.00 where ProductID = 11115